export interface Task {
    id: string;
    title: string;
    description: string;
    status: string;
    createdAt: string;
    updatedAt: string;
}
export interface CreateTaskRequest {
    title: string;
    description: string;
    status?: string;
}
export interface UpdateTaskRequest {
    title?: string;
    description?: string;
    status?: string;
}
export interface TasksApiResponse<T> {
    data: T;
}
export interface TasksApiErrorResponse {
    error: string;
}
//# sourceMappingURL=task.types.d.ts.map