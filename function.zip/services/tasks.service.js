"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TasksService = void 0;
const logger_1 = __importDefault(require("../utils/logger"));
class TasksService {
    constructor(tasksApiClient) {
        this.tasksApiClient = tasksApiClient;
    }
    async createTask(request) {
        try {
            logger_1.default.info('Creating task', { request });
            const task = await this.tasksApiClient.createTask(request);
            logger_1.default.info('Task created successfully', { taskId: task.id });
            return task;
        }
        catch (error) {
            logger_1.default.error('Error creating task', { error });
            throw error;
        }
    }
    async getTask(id) {
        try {
            logger_1.default.info('Getting task', { taskId: id });
            const task = await this.tasksApiClient.getTask(id);
            return task;
        }
        catch (error) {
            logger_1.default.error('Error getting task', { taskId: id, error });
            throw error;
        }
    }
    async listTasks(status) {
        try {
            logger_1.default.info('Listing tasks', { status });
            const tasks = await this.tasksApiClient.listTasks(status);
            return tasks;
        }
        catch (error) {
            logger_1.default.error('Error listing tasks', { status, error });
            throw error;
        }
    }
    async updateTask(id, request) {
        try {
            logger_1.default.info('Updating task', { taskId: id, request });
            const task = await this.tasksApiClient.updateTask(id, request);
            logger_1.default.info('Task updated successfully', { taskId: task.id });
            return task;
        }
        catch (error) {
            logger_1.default.error('Error updating task', { taskId: id, error });
            throw error;
        }
    }
    async deleteTask(id) {
        try {
            logger_1.default.info('Deleting task', { taskId: id });
            await this.tasksApiClient.deleteTask(id);
            logger_1.default.info('Task deleted successfully', { taskId: id });
        }
        catch (error) {
            logger_1.default.error('Error deleting task', { taskId: id, error });
            throw error;
        }
    }
}
exports.TasksService = TasksService;
//# sourceMappingURL=tasks.service.js.map