import { StatusConfigApiClient } from '../clients/status-config-api.client';
import { StatusConfig, CreateStatusConfigRequest, UpdateStatusConfigRequest, ReorderStatusesRequest } from '../types/status-config.types';
export declare class StatusConfigService {
    private statusConfigApiClient;
    constructor(statusConfigApiClient: StatusConfigApiClient);
    createStatus(request: CreateStatusConfigRequest): Promise<StatusConfig>;
    getStatus(statusKey: string): Promise<StatusConfig>;
    listStatuses(): Promise<StatusConfig[]>;
    updateStatus(statusKey: string, request: UpdateStatusConfigRequest): Promise<StatusConfig>;
    deleteStatus(statusKey: string): Promise<void>;
    reorderStatuses(request: ReorderStatusesRequest): Promise<void>;
}
//# sourceMappingURL=status-config.service.d.ts.map