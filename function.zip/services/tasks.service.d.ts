import { TasksApiClient } from '../clients/tasks-api.client';
import { Task, CreateTaskRequest, UpdateTaskRequest } from '../types/task.types';
export declare class TasksService {
    private tasksApiClient;
    constructor(tasksApiClient: TasksApiClient);
    createTask(request: CreateTaskRequest): Promise<Task>;
    getTask(id: string): Promise<Task>;
    listTasks(status?: string): Promise<Task[]>;
    updateTask(id: string, request: UpdateTaskRequest): Promise<Task>;
    deleteTask(id: string): Promise<void>;
}
//# sourceMappingURL=tasks.service.d.ts.map