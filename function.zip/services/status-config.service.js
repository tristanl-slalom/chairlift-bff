"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.StatusConfigService = void 0;
const logger_1 = __importDefault(require("../utils/logger"));
class StatusConfigService {
    constructor(statusConfigApiClient) {
        this.statusConfigApiClient = statusConfigApiClient;
    }
    async createStatus(request) {
        logger_1.default.info('Creating status', { statusKey: request.statusKey });
        return await this.statusConfigApiClient.createStatus(request);
    }
    async getStatus(statusKey) {
        logger_1.default.info('Getting status', { statusKey });
        return await this.statusConfigApiClient.getStatus(statusKey);
    }
    async listStatuses() {
        logger_1.default.info('Listing statuses');
        return await this.statusConfigApiClient.listStatuses();
    }
    async updateStatus(statusKey, request) {
        logger_1.default.info('Updating status', { statusKey });
        return await this.statusConfigApiClient.updateStatus(statusKey, request);
    }
    async deleteStatus(statusKey) {
        logger_1.default.info('Deleting status', { statusKey });
        await this.statusConfigApiClient.deleteStatus(statusKey);
    }
    async reorderStatuses(request) {
        logger_1.default.info('Reordering statuses', { count: request.statuses.length });
        await this.statusConfigApiClient.reorderStatuses(request);
    }
}
exports.StatusConfigService = StatusConfigService;
//# sourceMappingURL=status-config.service.js.map