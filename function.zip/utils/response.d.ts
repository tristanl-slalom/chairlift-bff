import { APIGatewayProxyResult } from 'aws-lambda';
export declare const createResponse: (statusCode: number, body: unknown, headers?: Record<string, string>) => APIGatewayProxyResult;
export declare const successResponse: (data: unknown, statusCode?: number) => APIGatewayProxyResult;
export declare const errorResponse: (message: string, statusCode?: number) => APIGatewayProxyResult;
//# sourceMappingURL=response.d.ts.map