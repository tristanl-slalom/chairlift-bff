"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorResponse = exports.successResponse = exports.createResponse = void 0;
const createResponse = (statusCode, body, headers = {}) => {
    return {
        statusCode,
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
            ...headers
        },
        body: JSON.stringify(body)
    };
};
exports.createResponse = createResponse;
const successResponse = (data, statusCode = 200) => {
    return (0, exports.createResponse)(statusCode, data);
};
exports.successResponse = successResponse;
const errorResponse = (message, statusCode = 500) => {
    return (0, exports.createResponse)(statusCode, { error: message });
};
exports.errorResponse = errorResponse;
//# sourceMappingURL=response.js.map