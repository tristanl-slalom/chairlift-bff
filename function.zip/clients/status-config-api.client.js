"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.statusConfigApiClient = exports.StatusConfigApiClient = void 0;
const axios_1 = __importDefault(require("axios"));
const logger_1 = __importDefault(require("../utils/logger"));
class StatusConfigApiClient {
    constructor(baseURL) {
        this.client = axios_1.default.create({
            baseURL,
            timeout: 10000,
            headers: {
                'Content-Type': 'application/json'
            }
        });
        this.client.interceptors.request.use((config) => {
            logger_1.default.info('Status Config API request', {
                method: config.method,
                url: config.url
            });
            return config;
        }, (error) => {
            logger_1.default.error('Status Config API request error', { error });
            return Promise.reject(error);
        });
        this.client.interceptors.response.use((response) => {
            logger_1.default.info('Status Config API response', {
                status: response.status,
                url: response.config.url
            });
            return response;
        }, (error) => {
            logger_1.default.error('Status Config API response error', {
                status: error.response?.status,
                message: error.message,
                url: error.config?.url
            });
            return Promise.reject(error);
        });
    }
    async createStatus(request) {
        const response = await this.client.post('/statuses', request);
        return response.data.data;
    }
    async getStatus(statusKey) {
        const response = await this.client.get(`/statuses/${statusKey}`);
        return response.data.data;
    }
    async listStatuses() {
        const response = await this.client.get('/statuses');
        return response.data.data;
    }
    async updateStatus(statusKey, request) {
        const response = await this.client.put(`/statuses/${statusKey}`, request);
        return response.data.data;
    }
    async deleteStatus(statusKey) {
        await this.client.delete(`/statuses/${statusKey}`);
    }
    async reorderStatuses(request) {
        await this.client.post('/statuses/reorder', request);
    }
}
exports.StatusConfigApiClient = StatusConfigApiClient;
const TASKS_API_URL = process.env.TASKS_API_URL || 'http://localhost:3001';
exports.statusConfigApiClient = new StatusConfigApiClient(TASKS_API_URL);
//# sourceMappingURL=status-config-api.client.js.map