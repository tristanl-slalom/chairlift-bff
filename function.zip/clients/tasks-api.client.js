"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.tasksApiClient = exports.TasksApiClient = void 0;
const axios_1 = __importDefault(require("axios"));
const logger_1 = __importDefault(require("../utils/logger"));
class TasksApiClient {
    constructor(baseURL) {
        this.client = axios_1.default.create({
            baseURL,
            timeout: 10000,
            headers: {
                'Content-Type': 'application/json'
            }
        });
        this.client.interceptors.request.use((config) => {
            logger_1.default.info('Tasks API request', {
                method: config.method,
                url: config.url
            });
            return config;
        }, (error) => {
            logger_1.default.error('Tasks API request error', { error });
            return Promise.reject(error);
        });
        this.client.interceptors.response.use((response) => {
            logger_1.default.info('Tasks API response', {
                status: response.status,
                url: response.config.url
            });
            return response;
        }, (error) => {
            logger_1.default.error('Tasks API response error', {
                status: error.response?.status,
                message: error.message,
                url: error.config?.url
            });
            return Promise.reject(error);
        });
    }
    async createTask(request) {
        const response = await this.client.post('/tasks', request);
        return response.data.data;
    }
    async getTask(id) {
        const response = await this.client.get(`/tasks/${id}`);
        return response.data.data;
    }
    async listTasks(status) {
        const params = status ? { status } : {};
        const response = await this.client.get('/tasks', { params });
        return response.data.data;
    }
    async updateTask(id, request) {
        const response = await this.client.put(`/tasks/${id}`, request);
        return response.data.data;
    }
    async deleteTask(id) {
        await this.client.delete(`/tasks/${id}`);
    }
}
exports.TasksApiClient = TasksApiClient;
const TASKS_API_URL = process.env.TASKS_API_URL || 'http://localhost:3001';
exports.tasksApiClient = new TasksApiClient(TASKS_API_URL);
//# sourceMappingURL=tasks-api.client.js.map