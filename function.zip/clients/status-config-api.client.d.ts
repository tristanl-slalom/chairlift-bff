import { StatusConfig, CreateStatusConfigRequest, UpdateStatusConfigRequest, ReorderStatusesRequest } from '../types/status-config.types';
export declare class StatusConfigApiClient {
    private client;
    constructor(baseURL: string);
    createStatus(request: CreateStatusConfigRequest): Promise<StatusConfig>;
    getStatus(statusKey: string): Promise<StatusConfig>;
    listStatuses(): Promise<StatusConfig[]>;
    updateStatus(statusKey: string, request: UpdateStatusConfigRequest): Promise<StatusConfig>;
    deleteStatus(statusKey: string): Promise<void>;
    reorderStatuses(request: ReorderStatusesRequest): Promise<void>;
}
export declare const statusConfigApiClient: StatusConfigApiClient;
//# sourceMappingURL=status-config-api.client.d.ts.map