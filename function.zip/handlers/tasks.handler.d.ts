import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const createTask: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const getTask: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const listTasks: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const updateTask: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const deleteTask: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=tasks.handler.d.ts.map