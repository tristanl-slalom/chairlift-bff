"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.reorderStatuses = exports.deleteStatus = exports.updateStatus = exports.listStatuses = exports.getStatus = exports.createStatus = void 0;
const status_config_api_client_1 = require("../clients/status-config-api.client");
const status_config_service_1 = require("../services/status-config.service");
const response_1 = require("../utils/response");
const logger_1 = __importDefault(require("../utils/logger"));
const axios_1 = require("axios");
const statusConfigService = new status_config_service_1.StatusConfigService(status_config_api_client_1.statusConfigApiClient);
const handleAxiosError = (error) => {
    if (error instanceof axios_1.AxiosError) {
        const status = error.response?.status || 500;
        const message = error.response?.data?.error || error.message;
        return (0, response_1.errorResponse)(message, status);
    }
    return (0, response_1.errorResponse)('Internal server error', 500);
};
const createStatus = async (event) => {
    try {
        if (!event.body) {
            return (0, response_1.errorResponse)('Request body is required', 400);
        }
        const request = JSON.parse(event.body);
        const status = await statusConfigService.createStatus(request);
        return (0, response_1.successResponse)(status, 201);
    }
    catch (error) {
        logger_1.default.error('Error in createStatus handler', { error });
        return handleAxiosError(error);
    }
};
exports.createStatus = createStatus;
const getStatus = async (event) => {
    try {
        const statusKey = event.pathParameters?.statusKey;
        if (!statusKey) {
            return (0, response_1.errorResponse)('Status key is required', 400);
        }
        const status = await statusConfigService.getStatus(statusKey);
        return (0, response_1.successResponse)(status);
    }
    catch (error) {
        logger_1.default.error('Error in getStatus handler', { error });
        return handleAxiosError(error);
    }
};
exports.getStatus = getStatus;
const listStatuses = async (_event) => {
    try {
        const statuses = await statusConfigService.listStatuses();
        return (0, response_1.successResponse)(statuses);
    }
    catch (error) {
        logger_1.default.error('Error in listStatuses handler', { error });
        return handleAxiosError(error);
    }
};
exports.listStatuses = listStatuses;
const updateStatus = async (event) => {
    try {
        const statusKey = event.pathParameters?.statusKey;
        if (!statusKey) {
            return (0, response_1.errorResponse)('Status key is required', 400);
        }
        if (!event.body) {
            return (0, response_1.errorResponse)('Request body is required', 400);
        }
        const request = JSON.parse(event.body);
        const status = await statusConfigService.updateStatus(statusKey, request);
        return (0, response_1.successResponse)(status);
    }
    catch (error) {
        logger_1.default.error('Error in updateStatus handler', { error });
        return handleAxiosError(error);
    }
};
exports.updateStatus = updateStatus;
const deleteStatus = async (event) => {
    try {
        const statusKey = event.pathParameters?.statusKey;
        if (!statusKey) {
            return (0, response_1.errorResponse)('Status key is required', 400);
        }
        await statusConfigService.deleteStatus(statusKey);
        return (0, response_1.successResponse)(null, 204);
    }
    catch (error) {
        logger_1.default.error('Error in deleteStatus handler', { error });
        return handleAxiosError(error);
    }
};
exports.deleteStatus = deleteStatus;
const reorderStatuses = async (event) => {
    try {
        if (!event.body) {
            return (0, response_1.errorResponse)('Request body is required', 400);
        }
        const request = JSON.parse(event.body);
        await statusConfigService.reorderStatuses(request);
        return (0, response_1.successResponse)(null, 204);
    }
    catch (error) {
        logger_1.default.error('Error in reorderStatuses handler', { error });
        return handleAxiosError(error);
    }
};
exports.reorderStatuses = reorderStatuses;
//# sourceMappingURL=status-config.handler.js.map