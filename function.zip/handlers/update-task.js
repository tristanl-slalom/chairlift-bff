"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const tasks_api_client_1 = require("../clients/tasks-api.client");
const tasks_service_1 = require("../services/tasks.service");
const response_1 = require("../utils/response");
const logger_1 = __importDefault(require("../utils/logger"));
const axios_1 = require("axios");
const tasksService = new tasks_service_1.TasksService(tasks_api_client_1.tasksApiClient);
const handleAxiosError = (error) => {
    if (error instanceof axios_1.AxiosError) {
        const status = error.response?.status || 500;
        const message = error.response?.data?.error || error.message;
        return (0, response_1.errorResponse)(message, status);
    }
    return (0, response_1.errorResponse)('Internal server error', 500);
};
const handler = async (event) => {
    try {
        const taskId = event.pathParameters?.id;
        if (!taskId) {
            return (0, response_1.errorResponse)('Task ID is required', 400);
        }
        if (!event.body) {
            return (0, response_1.errorResponse)('Request body is required', 400);
        }
        const request = JSON.parse(event.body);
        const task = await tasksService.updateTask(taskId, request);
        return (0, response_1.successResponse)(task);
    }
    catch (error) {
        logger_1.default.error('Error in updateTask handler', { error });
        return handleAxiosError(error);
    }
};
exports.handler = handler;
//# sourceMappingURL=update-task.js.map