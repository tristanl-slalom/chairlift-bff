import { APIGatewayProxyEvent, APIGatewayProxyResult } from 'aws-lambda';
export declare const createStatus: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const getStatus: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const listStatuses: (_event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const updateStatus: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const deleteStatus: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
export declare const reorderStatuses: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
//# sourceMappingURL=status-config.handler.d.ts.map